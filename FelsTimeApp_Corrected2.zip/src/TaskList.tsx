import '../style.css';
import { useState, useEffect } from 'react';

type TaskItem = {
  id: string;
  title: string;
  done: boolean;
};

type ArchivedItem = {
  id: string;
  title: string;
  category: string;
  archivedBy: 'done' | 'deleted';
  archivedAt: string;
};

function TaskList() {
  const [taskList, setTaskList] = useState<TaskItem[]>([]);
  const [routineList, setRoutineList] = useState<TaskItem[]>([]);
  const [archivedTasks, setArchivedTasks] = useState<ArchivedItem[]>([]);
  const [showArchive, setShowArchive] = useState(false);

  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'task' | 'routine'>('task');
  const [reminderMinutes, setReminderMinutes] = useState(0);

  useEffect(() => {
    const data = localStorage.getItem('fel_tasks');
    if (data) {
      const parsed = JSON.parse(data);
      setTaskList(parsed.taskList || []);
      setRoutineList(parsed.routineList || []);
      setArchivedTasks(parsed.archivedTasks || []);
    }
  }, []);

  const saveToLocalStorage = () => {
    localStorage.setItem('fel_tasks', JSON.stringify({ taskList, routineList, archivedTasks }));
  };

  const requestNotificationPermission = async () => {
    if (Notification.permission === 'default') {
      await Notification.requestPermission();
    }
  };

  const handleAdd = async () => {
    if (!newTitle.trim()) return;
    const newTask: TaskItem = {
      id: Date.now().toString(),
      title: newTitle.trim(),
      done: false
    };

    if (newCategory === 'task') {
      const updated = [...taskList, newTask];
      setTaskList(updated);
    } else {
      const updated = [...routineList, newTask];
      setRoutineList(updated);
    }

    if (reminderMinutes > 0) {
      await requestNotificationPermission();
      setTimeout(() => {
        if (Notification.permission === 'granted') {
          new Notification('リマインダー', {
            body: `「${newTitle.trim()}」の時間です。`,
          });
        }
      }, reminderMinutes * 60 * 1000);
    }

    setNewTitle('');
    setReminderMinutes(0);
    setTimeout(saveToLocalStorage, 100);
  };

  const archiveAndRemove = (
    list: TaskItem[],
    setList: (val: TaskItem[]) => void,
    id: string,
    category: string,
    reason: 'done' | 'deleted'
  ) => {
    const item = list.find(t => t.id === id);
    if (!item) return;
    const updatedList = list.filter(t => t.id !== id);
    const updatedArchive = [
      ...archivedTasks,
      { ...item, category, archivedBy: reason, archivedAt: new Date().toISOString().split('T')[0] }
    ];
    setList(updatedList);
    setArchivedTasks(updatedArchive);
    setTimeout(saveToLocalStorage, 100);
  };

  const toggleTaskDone = (id: string) =>
    archiveAndRemove(taskList, setTaskList, id, 'task', 'done');
  const toggleRoutineDone = (id: string) =>
    setRoutineList(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  const deleteTask = (id: string) =>
    archiveAndRemove(taskList, setTaskList, id, 'task', 'deleted');
  const deleteRoutine = (id: string) =>
    archiveAndRemove(routineList, setRoutineList, id, 'routine', 'deleted');

  const restoreTask = (task: ArchivedItem) => {
    const restored: TaskItem = { id: task.id, title: task.title, done: false };
    if (task.category === 'task') {
      setTaskList(prev => [...prev, restored]);
    } else {
      setRoutineList(prev => [...prev, restored]);
    }
    setArchivedTasks(prev => prev.filter(t => t.id !== task.id));
    setTimeout(saveToLocalStorage, 100);
  };

  const filteredArchive = archivedTasks.filter(t => {
    const d = new Date(t.archivedAt);
    const limit = new Date();
    limit.setDate(limit.getDate() - 30);
    return d >= limit;
  });

  return (
    <div className="task-list">
      <h1>Fel'sTime</h1>

      <div style={{ marginBottom: '1em' }}>
        <input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="新しいタスク名" />
        <select value={newCategory} onChange={e => setNewCategory(e.target.value as any)} style={{ marginLeft: '0.5em' }}>
          <option value="task">今日のタスク</option>
          <option value="routine">ルーチン</option>
        </select>
        <select value={reminderMinutes} onChange={e => setReminderMinutes(Number(e.target.value))} style={{ marginLeft: '0.5em' }}>
          <option value={0}>通知なし</option>
          <option value={5}>5分後に通知</option>
          <option value={10}>10分後に通知</option>
          <option value={30}>30分後に通知</option>
        </select>
        <button onClick={handleAdd} style={{ marginLeft: '0.5em' }}>追加</button>
      </div>

      <Section title="Task" list={taskList} onToggle={toggleTaskDone} onDelete={deleteTask} />
      <Section title="Routine" list={routineList} onToggle={toggleRoutineDone} onDelete={deleteRoutine} />

      <section>
        <div onClick={() => setShowArchive(prev => !prev)} style={{ cursor: 'pointer' }}>
          <h3>[{showArchive ? '▼' : '▶'}] アーカイブ</h3>
        </div>
        {showArchive && (
          <ul>
            {filteredArchive.map(task => (
              <li key={task.id}>
                [{task.archivedBy === 'done' ? '完了' : '削除'}] {task.title}（{task.category}） - {task.archivedAt}
                <button onClick={() => restoreTask(task)} style={{ marginLeft: '0.5em' }}>↩ 戻す</button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

type SectionProps = {
  title: string;
  list: TaskItem[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
};

function Section({ title, list, onToggle, onDelete }: SectionProps) {
  const remaining = list.filter(t => !t.done).length;
  return (
    <section>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h2>{title}</h2>
        <span>残り: {remaining}</span>
      </div>
      <ul>
        {list.map(task => (
          <li key={task.id}>
            <input
              type="checkbox"
              checked={task.done}
              onChange={() => onToggle(task.id)}
            />
            <span style={{ marginLeft: '0.5em' }}>{task.title}</span>
            <button onClick={() => onDelete(task.id)} style={{ marginLeft: '0.5em' }}>🗑</button>
          </li>
        ))}
      </ul>
    </section>
  );
}

export default TaskList;
